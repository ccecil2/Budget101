package Data;

import com.example.testapp.Data.Enum.Money;


/**
 * Contains a category object.
 */
public final class Category
{
    private final int ID;
    private boolean alarm;
    private String name;
    private Money money;


    /**
     * Creates a category object.
     * @param id - ID of category
     * @param name - Name of category
     * @param alarm - Alarm on/off
     * @param money - Money type
     */
    public Category(int id, String name, int alarm, int money)
    {
        this.ID = id;
        this.name = name;
        this.setAlarm(alarm);
        this.money = Money.toMoney(money);
    }


    /**
     * Creates a category object.
     * @param id - ID of category
     * @param name - Name of category
     * @param alarm - Alarm on/off
     * @param money - Money type
     */
    public Category(int id, String name, boolean alarm, Money money)
    {
        this.ID = id;
        this.name = name;
        this.alarm = alarm;
        this.money = money;
    }


    /**
     * Copy constructor
     * @param cat Object to copy
     */
    public Category(Category cat)
    {
        this.ID = cat.getID();
        this.name = cat.getName();
        this.alarm = cat.isAlarm();
        this.money = cat.getMoney();
    }


    /**
     * Translates int to boolean for alarm status.
     * @param alarm 1 for true, 0 for false
     */
    private void setAlarm(int alarm)
    {
        if (alarm == 1)
            this.alarm = true;
        else
            this.alarm = false;
    }


    /**
     * Returns the category's ID.
     * @return ID for database
     */
    public int getID()
    {
        return this.ID;
    }


    /**
     * Returns the category's name.
     * @return name
     */
    public String getName()
    {
        return this.name;
    }


    /**
     * Returns the alarm state.
     * @return boolean of alarm
     */
    public boolean isAlarm()
    {
        return this.alarm;
    }


    /**
     * Returns the alarm as an int.
     * @return 1 for true, 0 for false
     */
    public static int getAlarmInt(boolean alarm)
    {
        if(alarm)
            return 1;
        else
            return 0;
    }


    /**
     * Returns the type of money. INCOME/EXPENSE
     * @return Money enum
     */
    public Money getMoney()
    {
        return this.money;
    }
}
