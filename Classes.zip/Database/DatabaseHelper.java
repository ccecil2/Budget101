package Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Used to access database budget.db.
 */
public final class DatabaseHelper extends SQLiteOpenHelper
{
    private static final String dbName = "budget.db";
    private static final int dbVersion = 1;

    public DatabaseHelper(Context context)
    {
        super(context, dbName, null, dbVersion);
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createUser = "CREATE TABLE IF NOT EXISTS User(" +
                "userName VARCHAR(20) PRIMARY KEY, " +
                "password VARCHAR(20) NOT NULL, " +
                "picture BLOB);";

        String createCategory = "CREATE TABLE IF NOT EXISTS Category(" +
                "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name VARCHAR(20) NOT NULL, " +
                "alarm INTEGER NOT NULL, " +
                "type INTEGER NOT NULL);";

        String createRecord = "CREATE TABLE IF NOT EXISTS Record(" +
                "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "amount DOUBLE NOT NULL, " +
                "comment VARCHAR(50), " +
                "date INTEGER NOT NULL, " +
                "FK_Category INTEGER, " +
                "FOREIGN KEY(FK_Category) REFERENCES Category(ID) " +
                "ON UPDATE CASCADE " +
                "ON DELETE SET NULL);";

        // Make tables
        db.execSQL(createUser);
        db.execSQL(createCategory);
        db.execSQL(createRecord);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE User");
        db.execSQL("DROP TABLE Record");
        db.execSQL("DROP TABLE Category");
        onCreate(db);
    }
}
