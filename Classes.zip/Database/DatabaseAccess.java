package Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.example.testapp.Data.Category;
import com.example.testapp.Data.Enum.Money;
import com.example.testapp.Data.Record;
import com.example.testapp.Data.User;

import java.io.ByteArrayOutputStream;
import java.util.Date;

/**
 * Used to access database budget.db.
 */
public final class DatabaseAccess {
    private SQLiteDatabase db;
    private DatabaseHelper dataHelper;


    /**
     * Contains connection and functionality with budget.db.
     * Close connection with close() when finished.
     */
    public DatabaseAccess(Context context) {
        this.dataHelper = new DatabaseHelper(context);
        this.db = this.dataHelper.getWritableDatabase();
    }


    /**
     * Close the database.
     */
    public void close() {
        this.dataHelper.close();
    }


    /**
     * Set the SQLite database object.
     *
     * @param data
     */
    public void setDatabaseCon(SQLiteDatabase data) {
        this.db = data;
    }


    /**
     * Saves passed input to database.
     * On success, a new Record object will be returned
     * or null if failed to save.
     *
     * @param amount  - Dollar amount
     * @param comment - User comment
     * @param date    - Date of record
     * @param cat     - Category for record
     * @return New Record object or null if failed
     */
    public Record newRecord(double amount, String comment, Date date, Category cat) {
        ContentValues insert = new ContentValues();
        insert.put("amount", amount);
        insert.put("comment", comment);
        insert.put("date", date.getTime());
        insert.put("FK_Category", cat.getID());

        int r = (int) this.db.insert("Record", null, insert);
        Record rec;

        if (r == -1)
            rec = null;
        else
            rec = new Record(r, amount, cat, date, comment);

        return rec;
    }


    /**
     * Saves passed input to database.
     * On success, a new Category object will be returned
     * or null if failed to save.
     *
     * @param name  - Name of category
     * @param alarm - Alarm on/off
     * @param m     - Money object
     * @return New Category object or null if failed
     */
    public Category newCategory(String name, boolean alarm, Money m) {
        ContentValues insert = new ContentValues();
        insert.put("name", name);
        insert.put("alarm", Category.getAlarmInt(alarm));
        insert.put("type", Money.toInt(m));

        int r = (int) this.db.insert("Category", null, insert);
        Category c;

        if (r == -1)
            c = null;
        else
            c = new Category(r, name, alarm, m);

        return c;
    }


    /**
     * Saves passed input to database.
     * On success, a new Category object will be returned
     * or null if failed to save.
     * Use User.hash() to hash password before passing
     * it to this function.
     *
     * @param name     - Username
     * @param password - Hashed password
     * @param image    - Bitmap image
     * @return New User object or null if failed
     */
    public User newUser(String name, String password, Bitmap image) {
        ContentValues insert = new ContentValues();
        insert.put("userName", name);
        insert.put("password", password);
        if(image != null) // Allow no image
            insert.put("picture", this.toByteArray(image));

        int r = (int) this.db.insert("User", null, insert);
        User u;

        if (r == -1)
            u = null;
        else
            u = new User(name, password, image);

        return u;
    }


    /**
     * Converts a Bitmap into a byte[].
     *
     * @param image - Bitmap to convert
     * @return byte[] of bitmap
     */
    private byte[] toByteArray(Bitmap image) {
        if (image == null)
            return null;

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }


    /**
     * Converts a byte[] into a Bitmap object.
     *
     * @param image - Array to convert
     * @return Bitmap object or null
     */
    private Bitmap toBitmap(byte[] image)
    {
        if(image == null || image.length == 0)
            return null;

        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }


    /**
     * Returns an array of all categories in the database.
     * Array will be zero length if no categories are in
     * the database.
     *
     * @return Array of category objects
     */
    public Category[] getAllCategories() {
        String[] col = {"ID", "name", "alarm", "type"};

        Cursor cursor = this.db.query("Category", col, null, null, null, null, null, null);

        Category[] cat = new Category[cursor.getCount()]; // Get row count
        for (int index = 0; cursor.moveToNext(); index++)
        {
            cat[index] = new Category(cursor.getInt(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3));
        }

        return cat;
    }


    /**
     * Checks database for given username and returns
     * a filled User object if found. Null if not found.
     * @param username - Username to check
     * @return User object or null
     */
    public User getUser(String username)
    {
        if(username == null || username == "")
            return null;

        String[] col = {"userName", "password", "picture"};
        String select = "userName = ?";
        String[] args = {username};
        Cursor cursor = this.db.query("User", col, select, args, null, null, null);

        User user = null;
        if(cursor.moveToFirst())
        {
            user = new User(cursor.getString(0), cursor.getString(1), toBitmap(cursor.getBlob(2)));
        }

        return user;
    }


    /**
     * Returns a category with given ID.
     * Null if ID is not found.
     * @param ID - ID of category
     * @return - Category object or null
     */
    public Category getCategory(int ID)
    {
        String[] col = {"ID", "name", "alarm", "type"};
        String selection = "ID = ?";
        String[] args = {Integer.toString(ID)};

        Cursor cursor = this.db.query("Category", col, selection, args, null, null, null, null);

        Category cat;
        if(cursor.moveToFirst())
        {
            cat = new Category(cursor.getInt(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3));
        }
        else
            cat = null;

        return cat;
    }

    /*
    getRecordByType()
    getRecordByDate()
    getRecordByID()
    updateCategory()
    getCategory()
    updateUser()
    */
}
